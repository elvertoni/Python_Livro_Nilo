##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 10/10.1451 - Sem Título.py
# Página: 344
# Título: Controlando duas TVs
##############################################################################
tv_sala = {"ligado": False, "canal": 2}
tv_quarto = {"ligado": True, "canal": 4}


def liga_tv(tv):
    tv["ligado"] = True


def desliga_tv(tv):
    tv["ligado"] = False


liga_tv(tv_sala)
desliga_tv(tv_quarto)
