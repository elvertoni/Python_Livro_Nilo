##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 10/10.1462 - Sem Título.py
# Página: 356
# Título: Importando a classe Cliente
##############################################################################
from clientes import Cliente

joão = Cliente("João da Silva", "777-1234")
maria = Cliente("Maria da Silva", "555-4321")
