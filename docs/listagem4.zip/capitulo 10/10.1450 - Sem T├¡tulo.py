##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 10/10.1450 - Sem Título.py
# Página: 343
# Título: TV com dicionário
##############################################################################
tv = {"ligado": False, "canal": 2}


def liga_tv(tv):
    tv["ligado"] = True


def desliga_tv(tv):
    tv["ligado"] = False
