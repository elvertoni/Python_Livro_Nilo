##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 10/10.1473 - Sem Título.py
# Página: 363
# Título: Exemplo de extrados de contas normal e especial
##############################################################################
Extrato CC N° 001

DEPÓSITO      1000.00
SAQUE           50.00
SAQUE          190.00

    Saldo:     760.00

Extrato CC N° 002

DEPÓSITO       500.00
DEPÓSITO       300.00
DEPÓSITO        95.15
SAQUE         1500.00

    Saldo:    -604.85
