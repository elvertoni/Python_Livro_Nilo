##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 08/08.1292 - Sem Título.py
# Página: 246
# Título: Saída do programa com finally
##############################################################################
Digite o índice que quer imprimir:1
Carlos
Tentativa 1
Digite o índice que quer imprimir:abc
Digite um número!
Tentativa 2
Digite o índice que quer imprimir:100
Tentativa 3
Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
IndexError: list index out of range
