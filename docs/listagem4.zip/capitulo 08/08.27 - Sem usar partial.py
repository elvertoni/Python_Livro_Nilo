##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 08/08.27 - Sem usar partial.py
##############################################################################
import operator


def executa(operação, símbolo, operando1, operando2):
    resultado = operação(float(operando1), float(operando2))
    print(f"{operando1} {símbolo} {operando2} = {resultado}")


operando1 = input("Operador 1: ")
operando2 = input("Operador 2: ")
operação = input("Operação: ").strip()
if operação == "+":
    executa(operator.add, operação, operando1, operando2)
elif operação == "-":
    executa(operator.sub, operação, operando1, operando2)
elif operação == "*":
    executa(operator.mul, operação, operando1, operando2)
elif operação == "/":
    executa(operator.truediv, operação, operando1, operando2)
