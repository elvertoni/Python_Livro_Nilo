##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 08/08.1266 - Sem Título.py
# Página: 230
# Título: Exemplo de uso de variáveis locais e globais
##############################################################################
a = 5


def muda_e_imprime():
    a = 7
    print(f"A dentro da função: {a}")


print(f"a antes de mudar: {a}")
muda_e_imprime()
print(f"a depois de mudar: {a}")
