##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 08/08.1296 - Sem Título.py
# Página: 248
# Título: Saída do programa que combina o finally com return
##############################################################################
Executado antes de retornar
2 0
Executado antes de retornar
Algo de errado aconteceu
