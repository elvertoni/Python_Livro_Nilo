##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 08/08.23 - Jogo do alienígena.py
##############################################################################
import random

MAX_TENTATIVAS = 3
árvore = random.randint(1, 100)
print("Um alienígena está escondido atrás de uma árvore")
print("Cada árvore foi numerada de 1 a 100.")
print("Você tem 3 tentativas para adivinhar em que árvore")
print("o alienígena se esconde.")

for tentativa in range(1, MAX_TENTATIVAS + 1):
    palpite = int(input(f"Árvore {tentativa}/{MAX_TENTATIVAS }: "))
    if palpite == árvore:
        print(f"Você acertou na {tentativa}\u00aa tentativa")
        break
    elif palpite > árvore:
        print("Muito alto")
    else:
        print("Muito baixo")
else:
    print("Você não conseguiu acertar.")
    print(f"O alienígena estava na árvore {árvore}")
