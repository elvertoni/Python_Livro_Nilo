##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 08/08.1373 - Sem Título.py
# Página: 280
# Título: Exemplo de condição sem usar o walrus operator
##############################################################################
a = 5
if a == 6:
    print("A vale 6")
else:
    print("A não vale 6")
