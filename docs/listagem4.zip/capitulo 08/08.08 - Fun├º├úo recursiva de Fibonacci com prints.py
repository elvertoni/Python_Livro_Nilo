##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 08/08.08 - Função recursiva de Fibonacci com prints.py
##############################################################################
def fibonacci(n):
    print(f"Calculando fibonacci {n}")
    if n <= 1:
        print(f"  Fibonacci de {n} = {n} ")
        return n
    else:
        print(f"  Fibonacci de {n} = fibonacci {n-1} + fibonacci {n-2} = ...")
        resultado = fibonacci(n - 1) + fibonacci(n - 2)
        print(f"  Fibonacci de {n} = fibonacci {n-1} + fibonacci {n-2} = {resultado}")
        return resultado


fibonacci(5)
