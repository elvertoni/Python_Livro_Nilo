##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 08/08.1374 - Sem Título.py
# Página: 281
# Título: Exemplo de while sem usar o walrus operator
##############################################################################
soma = 0.0
valor = input("Digite fim para terminar ou um número para somar:")
while valor != "fim":
    soma += float(valor)
    valor = input("Digite fim para terminar ou um número para somar:")
print(f"A soma é: {soma}")
