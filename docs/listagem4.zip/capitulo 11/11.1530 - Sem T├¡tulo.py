##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 11/11.1530 - Sem Título.py
# Página: 414
# Título: Regiões com mais de 5 estados
##############################################################################
Região Estados População  Mínima    Máxima      Média    Total (soma)
====== =======          ========= ========== ==========  ============
NE           9          2,195,662 15,044,127  6,199,406    55,794,654
N            7            488,072  7,969,655  2,426,212    16,983,485
