##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 11/11.1533 - Sem Título.py
# Página: 415
# Título: Saída sem tratamento dos registros da tabela feriados
##############################################################################
(1, "2018-01-01", "Confraternização Universal")
(2, "2018-04-21", "Tiradentes")
(3, "2018-05-01", "Dia do trabalhador")
(4, "2018-09-07", "Independência")
(5, "2018-10-12", "Padroeira do Brasil")
(6, "2018-11-02", "Finados")
(7, "2018-11-15", "Proclamação da República")
(8, "2018-12-25", "Natal")
