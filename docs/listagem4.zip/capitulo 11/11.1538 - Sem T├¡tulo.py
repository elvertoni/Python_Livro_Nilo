##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 11/11.1538 - Sem Título.py
# Página: 417
# Título: Outra forma de formatar a data
##############################################################################
import sqlite3
import datetime

hoje = datetime.date.today()
hoje60dias = hoje + datetime.timedelta(days=60)
with sqlite3.connect("brasil.db", detect_types=sqlite3.PARSE_DECLTYPES) as conexão:
    conexão.row_factory = sqlite3.Row
    for feriado in conexão.execute(
        "select * from feriados where data >= ? and data <= ?", (hoje, hoje60dias)
    ):
        print(f"{feriado['data']:%d/%m} {feriado['descrição']}")
