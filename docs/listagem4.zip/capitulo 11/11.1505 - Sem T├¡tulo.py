##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 11/11.1505 - Sem Título.py
# Página: 396
# Título: Exemplo de saída do programa que faz a query no banco
##############################################################################
Nome: Nilo
Telefone: 7788 - 1432
