##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 11/11.1518 - Sem Título.py
# Página: 409
# Título: Alterando a tabela estados para adicionar sigla e região
##############################################################################
alter table estados add sigla text
alter table estados add região text
