##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 11/11.1506 - Sem Título.py
# Página: 397
# Título: Inserindo vários registros com executemany
##############################################################################
import sqlite3

dados = [("João", "98901-0109"), ("André", "98902-8900"), ("Maria", "97891-3321")]
conexão = sqlite3.connect("agenda.db")
cursor = conexão.cursor()
cursor.executemany(
    """
      insert into agenda (nome, telefone)
      values(?, ?)
      """,
    dados,
)
conexão.commit()
cursor.close()
conexão.close()
