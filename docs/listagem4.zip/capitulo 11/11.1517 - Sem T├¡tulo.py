##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 11/11.1517 - Sem Título.py
# Página: 408
# Título: Exibindo a população de cada estado ordenados por nome
##############################################################################
import sqlite3

with sqlite3.connect("brasil.db") as conexão:
    conexão.row_factory = sqlite3.Row
    print(f"{'Id':3s} {'Estado':<20s} {'População':12s}")
    print("=" * 37)
    for estado in conexão.execute("select * from estados order by nome"):
        print(f"{estado['id']:3d} {estado['nome']:<20s} {estado['população']:12d}")
