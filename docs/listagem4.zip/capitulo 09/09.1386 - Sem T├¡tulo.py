##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 09/09.1386 - Sem Título.py
# Página: 292
# Título: Criando e trocando de diretório no Windows
##############################################################################
C:\User\User\pai> md filho
C:\User\User\pai> cd filho
C:\User\User\pai\filho>
