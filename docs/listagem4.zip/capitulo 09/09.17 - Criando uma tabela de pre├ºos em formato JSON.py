##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 09/09.17 - Criando uma tabela de preços em formato JSON.py
##############################################################################
import json
from pathlib import Path

tabela_de_preços = {}

print("Criador da tabela de preços")
print("Digite um nome de produto em branco para terminar")
while produto := input("Nome do produto:"):
    preço = input("Preço:")
    tabela_de_preços[produto] = preço

with Path("preços.json").open("w", encoding="utf-8") as arquivo:
    json.dump(tabela_de_preços, arquivo)
