##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 09/09.16 - Abrindo um arquivo JSON e usando os dados.py
##############################################################################
import json
from pathlib import Path

with Path("lista.json").open(encoding="utf-8") as arquivo:
    turma = json.load(arquivo)
for aluno in turma:
    print("Nome:", aluno["nome"])
    print("Notas:", aluno["notas"])
    print("Média:", sum(aluno["notas"]) / len(aluno["notas"]))
    print()
