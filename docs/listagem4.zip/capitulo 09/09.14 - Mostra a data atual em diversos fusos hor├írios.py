##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 09/09.14 - Mostra a data atual em diversos fusos horários.py
##############################################################################
from zoneinfo import ZoneInfo
from datetime import datetime

bruxelas = ZoneInfo("Europe/Brussels")
nova_iorque = ZoneInfo("America/New_York")
tokio = ZoneInfo("Japan")
manaus = ZoneInfo("America/Manaus")
brasília = ZoneInfo("Brazil/East")
rio_branco = ZoneInfo("America/Rio_Branco")
agora = datetime.now()
print("Agora em:")
print("Bruxelas    ", agora.astimezone(bruxelas))
print("Nova Iorque ", agora.astimezone(nova_iorque))
print("Tokio       ", agora.astimezone(tokio))
print("\nAgora no Brasil:")
print("Rio Branco  ", agora.astimezone(rio_branco))
print("Manaus      ", agora.astimezone(manaus))
print("Brasília    ", agora.astimezone(brasília))
