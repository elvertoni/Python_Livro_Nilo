##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 09/09.1443 - Sem Título.py
# Página: 331
# Título: Programa em Python mostrado byte a byte
##############################################################################
69 6d 70 6f 72 74 20 73 79 73 0d 0a 69 6d 70 6f import sys..impo
72 74 20 69 74 65 72 74 6f 6f 6c 73 0d 0a 0d 0a rt itertools….
0d 0a 64 65 66 20 69 6d 70 72 69 6d 65 5f 62 79 ..def imprime_by
74 65 73 28 69 6d 61 67 65 6d 2c 20 62 79 74 65 tes(imagem, byte
73 5f 70 6f 72 5f 6c 69 6e 68 61 3d 31 36 29 3ª s_por_linha=16):
0d 0a 20 20 20 20 66 6f 72 20 62 20 69 6e 20 69 ..    for b in i
74 65 72 74 6f 6f 6c 73 2e 62 61 74 63 68 65 64 tertools.batched
28 69 6d 61 67 65 6d 2c 20 62 79 74 65 73 5f 70 (imagem, bytes_p
6f 72 5f 6c 69 6e 68 61 29 3ª 0d 0a 20 20 20 20 or_linha):..
20 20 20 20 68 65 78 5f 76 69 65 77 20 3d 20 22     hex_view = "
20 22 2e 6a 6f 69 6e 28 5b 66 22 7b 76 3a 30 32  ".join([f"{v:02
78 7d 22 20 66 6f 72 20 76 20 69 6e 20 62 5d 29 x}" for v in b])
0d 0a 20 20 20 20 20 20 20 20 74 76 69 65 77 20 ..        tview
3d 20 22 22 2e 6a 6f 69 6e 28 5b 63 68 72 28 76 = "".join([chr(v
29 20 69 66 20 63 68 72 28 76 29 2e 69 73 70 72 ) if chr(v).ispr
69 6e 74 61 62 6c 65 28 29 20 65 6c 73 65 20 22 intable() else "
2e 22 20 66 6f 72 20 76 20 69 6e 20 62 5d 29 0d ." for v in b]).
0a 20 20 20 20 20 20 20 20 70 72 69 6e 74 28 66 .        print(f
22 7b 68 65 78 5f 76 69 65 77 7d 20 7b 22 20 22 "{hex_view} {" "
20 2ª 20 33 20 2ª 20 28 62 79 74 65 73 5f 70 6f  * 3 * (bytes_po
72 5f 6c 69 6e 68 61 20 2d 20 6c 65 6e 28 62 29 r_linha – len(b)
29 7d 7b 74 76 69 65 77 7d 22 29 0d 0a 0d 0a 0d )}{tview}")…..
0a 70 72 69 6e 74 28 5f 5f 6e 61 6d 65 5f 5f 29 .print(__name__)
0d 0a 69 66 20 5f 5f 6e 61 6d 65 5f 5f 20 3d 3d ..if __name__ ==
20 22 5f 5f 6d 61 69 6e 5f 5f 22 3a 0d 0a 20 20  "__main__":..
20 20 77 69 74 68 20 6f 70 65 6e 28 73 79 73 2e   with open(sys.
61 72 67 76 5b 31 5d 2c 20 22 72 62 22 29 20 61 argv[1], "rb") a
73 20 66 3ª 0d 0a 20 20 20 20 20 20 20 20 69 6d s f:..        im
61 67 65 6d 20 3d 20 66 2e 72 65 61 64 28 29 0d agem = f.read().
0a 20 20 20 20 69 6d 70 72 69 6d 65 5f 62 79 74 .    imprime_byt
65 73 28 69 6d 61 67 65 6d 29 0d 0a             es(imagem)..
