##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 09/09.1435 - Sem Título.py
# Página: 326
# Título: Exemplo de arquivo JSON com lista
##############################################################################
[
    {"nome": "João", "notas": [3, 7, 8.5, 1.5]},
    {"nome": "Maria", "notas": [9.5, 8.5, 10, 7]},
    {"nome": "Marcos", "notas": [7, 7.5, 8, 9]},
    {"nome": "Zacarias", "notas": [6.5, 7, 8, 9.5]},
]
