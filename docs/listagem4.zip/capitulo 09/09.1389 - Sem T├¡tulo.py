##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 09/09.1389 - Sem Título.py
# Página: 294
# Título: Criando um programa na linha de comando com echo no Linux
##############################################################################
nilo@tlinux:~$ cd pai/filho
nilo@tlinux:~/pai/filho$ echo "print('Criado por echo')" > teste.py
nilo@tlinux:~/pai/filho$ cat teste.py
print('Criado por echo')
