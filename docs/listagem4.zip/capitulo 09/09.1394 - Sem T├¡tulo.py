##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 09/09.1394 - Sem Título.py
# Página: 305
# Título: Página html simples
##############################################################################
 1  <!DOCTYPE html>
 2  <html lang="pt-BR">
 3  <head>
 4  <meta charset="utf-8">
 5  <title>Título da Página</title>
 6  </head>
 7  <body>
 8  Olá!
 9  </body>
10  </html>
