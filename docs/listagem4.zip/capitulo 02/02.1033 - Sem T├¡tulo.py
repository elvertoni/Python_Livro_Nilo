##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 02/02.1033 - Sem Título.py
# Página: 47
# Título: Instalando o Python no OS X
##############################################################################
brew update
brew install python@3.12 python-tk@3.12
