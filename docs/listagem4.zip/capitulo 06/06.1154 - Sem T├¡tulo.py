##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 06/06.1154 - Sem Título.py
# Página: 170
# Título: For com posição sem enumerate
##############################################################################
L = [5, 9, 13]
x = 0
for e in L:
    print(f"[{x}] {e}")
    x += 1
