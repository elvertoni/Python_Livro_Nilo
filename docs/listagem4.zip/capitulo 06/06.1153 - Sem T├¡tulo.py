##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 06/06.1153 - Sem Título.py
# Página: 169
# Título: Exemplo com range (inicial, final e incremento)
##############################################################################
for t in range(3, 33, 3):
    print(t, end=" ")
print()
