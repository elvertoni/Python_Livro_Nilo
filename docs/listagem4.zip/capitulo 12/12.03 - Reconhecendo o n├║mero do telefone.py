##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 12/12.03 - Reconhecendo o número do telefone.py
##############################################################################
entrada = "Compre por R$50,72. Ligue já (92)5431-2201 antes de 10/12/2033."
Saída = []
telefone = []
def número(entrada, qmin, qmax):
    num = 0
    for caractere in entrada:
        if caractere.isnumeric():
            num += 1
        else:
            break
    if qmin <= num <= qmax:
        return True, 0, num – 1
    return False, -1, -1
def ddd(entrada):
    estado = posição = 0
    código_ddd = []
    while posição < len(entrada):
        caractere = entrada[posição]
        if estado == 0 and caractere == "(":
            estado = 1
            código_ddd.append(caractere)
        elif estado == 1:
            achou, início, fim = número(entrada[posição:], 2, 3)
            if achou:
                código_ddd.append(entrada[posição + início : posição + fim + 1])
                estado = 2
                posição += fim
            else:
                break
        elif estado == 2:
            if caractere == ")":
                return True, 0, posição
            break
        else:
            break
        posição += 1
    return False, -1, -1
for posição in range(len(entrada)):
    achou, início, fim = ddd(entrada[posição:])
    if achou:
        print(f"DDD encontrado nas posições: {posição+início} a {posição+fim}")
        print(entrada[posição + início : posição + fim + 1])
