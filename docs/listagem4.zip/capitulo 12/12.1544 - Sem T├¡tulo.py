##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 12/12.1544 - Sem Título.py
# Página: 438
# Título: Função telefone usando partial
##############################################################################
def telefone(entrada):
    return verifica_padrão(
        entrada,
        [
            partial(ddd),
            partial(número, qmin=4, qmax=4),
            partial(sequência, padrão="-"),
            partial(número, qmin=4, qmax=4),
        ],
    )
