##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 12/12.1543 - Sem Título.py
# Página: 437
# Título: Função ddd
##############################################################################
def ddd(entrada):
    achou, _, fim = verifica_padrão(
        entrada,
        [
            partial(sequência, padrão="("),
            partial(número, qmin=2, qmax=3),
            partial(sequência, padrão=")"),
        ],
    )
    return (1, 0, fim) if achou > 0 else (-1, -1, -1)
