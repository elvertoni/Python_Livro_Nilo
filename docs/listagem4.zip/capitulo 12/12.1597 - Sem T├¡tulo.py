##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 12/12.1597 - Sem Título.py
# Página: 452
# Título: Exemplo sem o uso de match
##############################################################################
nome = input("Digite um nome:")
lnome = nome.lower()
if lnome == "nilo":
    print("Olá Nilo!")
elif lnome == "joão" or lnome == "maria":
    print("Tudo bom?")
else:
    print("Não conheço você")
