##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 12/12.04 - Programa modificado para reconhecer sequências.py
##############################################################################
entrada = "Compre por R$50,72. Ligue já (92)5431-2201 antes de 10/12/2033."


def número(entrada, qmin, qmax):
    num = 0
    for caractere in entrada:
        if caractere.isnumeric():
            num += 1
        else:
            break
    if qmin <= num <= qmax:
        return num, 0, num - 1
    else:
        return -1, -1, -1


def sequência(entrada, padrão):
    posição, posição_máxima = 0, len(padrão)
    for caractere in entrada:
        if caractere == padrão[posição]:
            posição += 1  # Caracteres iguais, testa o próximo caractere
        else:
            break  # Saiu da sequência
        if posição == posição_máxima:  # Achou toda a sequência
            return 1, 0, posição - 1
    return -1, -1, -1


def ddd(entrada):
    achou, _, _ = sequência(entrada[0], "(")
    if achou > 0:
        achou, _, n_fim = número(entrada[1:], 2, 3)
        if achou > 0:
            achou, _, _ = sequência(entrada[n_fim + 2], ")")
            if achou > 0:
                return 1, 0, achou + 2
    return -1, -1, -1


for posição in range(len(entrada)):
    achou, início, fim = ddd(entrada[posição:])
    if achou > 0:
        print(f"DDD encontrado nas posições: {posição+início} a {posição+fim}")
        print(entrada[posição + início : posição + fim + 1])
