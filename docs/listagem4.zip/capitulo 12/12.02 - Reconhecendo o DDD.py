##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 12/12.02 - Reconhecendo o DDD.py
##############################################################################
entrada = "Compre por R$50,72. Ligue já (92)5431-2201 antes de 10/12/2033."
Saída = []
telefone = []


def ddd(entrada):
    estado = 0
    posição_ddd = []
    for posição, caractere in enumerate(entrada):
        if estado == 0 and caractere == "(":
            estado = 1
            posição_ddd.append(caractere)
        elif estado == 1 and caractere.isnumeric() and posição <= 3:
            posição_ddd.append(caractere)
        elif estado == 1 and caractere == ")":
            estado = 2
            codigo_ddd.append(caractere)
            return True, 0, posicao
        else:
            break
    return False, -1, -1


for posicao in range(len(entrada)):
    achou, inicio, fim = ddd(entrada[posição:])
    if achou:
        print(f"DDD encontrado nas posições: {posição+inicio} a {posição+fim}")
        print(entrada[posição + inicio : posição + fim + 1])
