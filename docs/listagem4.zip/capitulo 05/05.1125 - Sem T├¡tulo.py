##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 05/05.1125 - Sem Título.py
# Página: 145
# Título: Repetindo até que seja digitado 0
##############################################################################
s = 0
while True:
    v = int(input("Digite um número a somar ou 0 para sair:"))
    if v == 0:
        break
    s += v
print(s)
