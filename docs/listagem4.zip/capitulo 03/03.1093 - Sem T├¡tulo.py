##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 03/03.1093 - Sem Título.py
# Página: 115
# Título: Exemplo de erro na entrada de dados
##############################################################################
Digite seu nome: Minduim
Digite sua idade: abc
Traceback (most recent call last):
  File "input/input2.py", line 2, in <module>
    idade = int(input("Digite sua idade: "))
ValueError: invalid literal for int() with base 10: 'abc'
