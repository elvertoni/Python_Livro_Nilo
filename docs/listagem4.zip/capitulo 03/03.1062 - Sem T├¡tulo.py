##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 03/03.1062 - Sem Título.py
# Página: 91
# Título: Exemplo de conversão do sistema binário para decimal
##############################################################################
1010 = 1 x 2 ** 3 + 0 x 2 ** 2 + 1 x 2 ** 1 + 0 x 2 ** 0
     = 1 x 8 + 0 x 4 + 1 x 2 + 0 x 1
     = 8 + 0 + 2 + 0
     = 10
