##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1617 - Sem Título.py
# Página: 485
# Título: Botões para trocar as cores
##############################################################################
self.lfrente = ttk.Label(self.barra, text="Cor de Frente")
self.lfrente.pack()
self.bfrente = tk.Button(
    self.barra, text="Cor", command=self.cor_frente, bg=self.cor_de_frente
)
self.bfrente.pack(fill="x")
self.lfundo = ttk.Label(self.barra, text="Cor de Fundo")
self.lfundo.pack()
self.bfundo = tk.Button(
    self.barra, text="Transparente", command=self.cor_fundo, bg=None
)
self.bfundo.pack(fill="x")
