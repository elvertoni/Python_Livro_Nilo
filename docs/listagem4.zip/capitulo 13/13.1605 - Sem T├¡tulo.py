##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1605 - Sem Título.py
# Página: 471
# Título: Usando padding
##############################################################################
self.quadro = ttk.Frame(self, padding="50 10")
self.l_temperatura = ttk.Label(self.quadro, text="Temperatura:")
self.l_temperatura.pack(pady=10)
self.temperatura = ttk.Entry(self.quadro)
self.temperatura.pack(ipady=10)
self.botao_CF = ttk.Button(
    self.quadro, text="Celsius para Fahrenheit", command=self.celsius_para_fahrenheit
)
self.botao_CF.pack(padx=10, pady=10, ipadx=5, ipady=5)
self.botao_FC = ttk.Button(
    self.quadro, text="Fahrenheit para Celsius", command=self.fahrenheit_para_celsius
)
