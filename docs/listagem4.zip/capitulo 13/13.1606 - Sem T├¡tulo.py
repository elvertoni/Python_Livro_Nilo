##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1606 - Sem Título.py
# Página: 477
# Título: Desenhando uma cruz no canvas
##############################################################################
self.cruz = []
self.cruz.append(self.canvas.create_line((0, 0, 0, 0), dash=[2, 4]))
self.cruz.append(self.canvas.create_line((0, 0, 0, 0), dash=[2, 4]))
