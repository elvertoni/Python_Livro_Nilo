##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1622 - Sem Título.py
# Página: 508
# Título: Selecionando com duplo clique
##############################################################################
def pega_selecionado(self):
    if item_selecionado := self.tabela.selection():
        id_selecionado = item_selecionado[0]
        return id_selecionado
    return None


def abre_janela(self, event):
    if id_selecionado := self.pega_selecionado():
        site = self.gerente.sites[id_selecionado]
    else:
        site = None
    self.mostra_site(site)


def mostra_site(self, site):
    self.janela = Janela(self, site, on_change=self.atualiza)
    self.janela.grab_set()
