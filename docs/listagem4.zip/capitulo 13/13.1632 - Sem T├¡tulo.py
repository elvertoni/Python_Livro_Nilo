##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1632 - Sem Título.py
# Página: 513
# Título: Gravando os dados em um arquivo json
##############################################################################
def grava(self, nome_do_arquivo):
    with open(nome_do_arquivo, "w") as arquivo:
        dados = []
        for site in self.sites.values():
            dados.append(
                {
                    "id": site.id,
                    "url": site.url,
                    "notas": site.notas,
                    "data": site.data,
                    "categoria": site.categoria,
                }
            )
        json.dump(dados, arquivo, indent=2, sort_keys=True)
