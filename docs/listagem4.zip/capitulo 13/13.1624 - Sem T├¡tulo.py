##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1624 - Sem Título.py
# Página: 510
# Título: Adicionando um menu
##############################################################################
self.menu = tk.Menu(self)
self.m_arquivo = tk.Menu(self.menu, tearoff=0)
self.m_arquivo.add_command(label="Ler", command=self.lê)
self.m_arquivo.add_command(label="Gravar", command=self.grava)
self.m_sites = tk.Menu(self.menu, tearoff=0)
self.m_sites.add_command(label="Adiciona", command=self.adiciona)
self.m_sites.add_command(label="Apaga", command=self.apaga)
self.m_sites.add_separator()
self.m_sites.add_command(label="Apaga todos", command=self.apaga_todos)
self.menu.add_cascade(label="Arquivo", menu=self.m_arquivo)
self.menu.add_cascade(label="Sites", menu=self.m_sites)
self.menu.add_command(label="Sobre", command=self.sobre)
self.config(menu=self.menu)
