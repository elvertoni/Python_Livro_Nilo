##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1627 - Sem Título.py
# Página: 511
# Título: Método apaga_todos usando askquestion e limpa
##############################################################################
def apaga_todos(self):
    if (
        askquestion(
            title="Apagar todos os sites", message="Confirma apagar todos os sites?"
        )
        == "yes"
    ):
        self.limpa()


def limpa(self):
    self.gerente.sites.clear()
    self.tabela.delete(*self.tabela.get_children())
