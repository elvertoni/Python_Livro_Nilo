##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1613 - Sem Título.py
# Página: 482
# Título: Mais ferramentas de desenho
##############################################################################
self.blinha = ttk.Button(
    self.barra, text="Linha", padding="10", command=self.ferramenta_linha
)
self.blinha.pack()
self.boval = ttk.Button(
    self.barra, text="Círculo", padding="10", command=self.ferramenta_oval
)
self.boval.pack()
self.bretângulo = ttk.Button(
    self.barra, text="Retângulo", padding="10", command=self.ferramenta_retângulo
)
self.bretângulo.pack()
