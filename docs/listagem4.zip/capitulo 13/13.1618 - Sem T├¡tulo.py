##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1618 - Sem Título.py
# Página: 485
# Título: Métodos para trocar as cores de frente e fundo
##############################################################################
def cor_fundo(self):
    cor = askcolor(title="Cor de fundo")
    self.cor_de_fundo = cor[1] or ""
    self.bfundo.config(
        text="Transparente" if self.cor_de_fundo == "" else "",
        background=self.cor_de_fundo or "SystemButtonFace",
    )


def cor_frente(self):
    cor = askcolor(title="Cor de frente")
    if cor[1]:
        self.cor_de_frente = cor[1]
        self.bfrente.config(background=self.cor_de_frente)
