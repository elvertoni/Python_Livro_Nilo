##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1607 - Sem Título.py
# Página: 478
# Título: Movendo a cruz com o mouse
##############################################################################
self.canvas.coords(self.cruz[0], event.x, 0, event.x, self.canvas.winfo_height())
self.canvas.coords(self.cruz[1], 0, event.y, self.canvas.winfo_width(), event.y)
