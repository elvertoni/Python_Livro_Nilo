##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1620 - Sem Título.py
# Página: 495
# Título: Dados de exemplo em formto json
##############################################################################
[
    {
        "url": "https://python.nilo.pro.br",
        "categoria": "Python",
        "data": "01-10-2010",
        "notas": "Livro de Python",
    },
    {
        "url": "https://www.novatec.com.br",
        "categoria": "Livros",
        "data": "01-01-2000",
        "notas": "Editora",
    },
]
