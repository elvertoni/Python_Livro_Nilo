##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.1615 - Sem Título.py
# Página: 483
# Título: Botões para desfazer e limpar
##############################################################################
bdesfaz = ttk.Button(self.barra, text="Desfaz", padding="10", command=self.desfaz)
bdesfaz.pack()
blimpa = ttk.Button(self.barra, text="Limpa", padding="10", command=self.limpa)
blimpa.pack()
