##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.09 - Gerente de sites.py
##############################################################################
import json
from site_registro import Site


class GerenteDeSites:
    def __init__(self):
        self.sites = {}

    def carrega(self, nome_do_arquivo):
        with open(nome_do_arquivo) as arquivo:
            dados = json.load(arquivo)
        self.sites.clear()
        for dado in dados:
            site = Site(
                id=dado.get("id"),
                categoria=dado.get("categoria"),
                data=dado["data"],
                url=dado["url"],
                notas=dado.get("notas"),
            )
            self.sites[site.id] = site
