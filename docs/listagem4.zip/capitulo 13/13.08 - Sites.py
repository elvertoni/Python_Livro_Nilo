##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2024
# Quarta Edição - Março/2024 - ISBN 978-85-7522-886-9
#
# Site: https://python.nilo.pro.br/
#
# Arquivo: capítulo 13/13.08 - Sites.py
##############################################################################
from uuid import uuid4
from datetime import date


class Site:
    def __init__(self, /, url=None, categoria=None, data=None, id=None, notas=None):
        if id is None:
            id = str(uuid4())
        self.id = id
        if data is None:
            data = date.today().strftime("%d-%m-%y")
        self.data = data
        self.url = url
        self.categoria = categoria
        self.notas = notas

    def __str__(self):
        return f"Site {self.id} {self.url} {self.categoria} {self.notas}"
